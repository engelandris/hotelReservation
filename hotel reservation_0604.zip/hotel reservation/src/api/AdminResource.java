package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.Date;
import java.util.List;

public class AdminResource {

    private static AdminResource adminResource;
    public static AdminResource getInstance(){
        if(adminResource==null){
            adminResource=new AdminResource();
        }
        return adminResource;
    }
    public static CustomerService customerService=CustomerService.getInstance();
    public static ReservationService reservationService=ReservationService.getInstance();

    public Customer getCustomer(String email) {
        return customerService.getCustomer(email);
    }

    public void addRoom(List<IRoom> rooms){
        for(IRoom rom: rooms) {
            reservationService.addRoom(rom);
        }
    }
    public Collection<IRoom> getAllRooms(){
        //add body
       /* Date checkInDate = null;
        Date checkOutDate=null;*/
       getAllRooms().add(reservationService.showAllRooms());
    return getAllRooms();

    }
    public Collection<Customer> getAllCustomers(){
        //add body

        return customerService.getAllCustomers();

    }
    public void displayAllReservations(){
        reservationService.printAllReservation();
    }
}

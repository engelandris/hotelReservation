package cli;

public class AdminMenu {

    public void start(){

    }
}

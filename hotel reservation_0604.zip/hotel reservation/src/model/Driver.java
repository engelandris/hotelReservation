package model;

public class Driver {

    public static void main(String[] args) {
        Customer customer= new Customer("first", "second", "l@gmail.com");
        System.out.println(customer);
        Customer customer2= new Customer("first", "second", "lol");
    }
}

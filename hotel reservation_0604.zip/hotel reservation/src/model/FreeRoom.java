package model;

public class FreeRoom extends Room{
    public FreeRoom(String roomNumber, double price, RoomType roomType) {
        super(roomNumber, 0, roomType);
    }
    @Override
    public String toString(){
        return "Room number: "+ getRoomNumber()+", type: " + getRoomType()+ "is for "+ getRoomPrice();
    }
    //not sure if this is really set to zero price, should be zero
}

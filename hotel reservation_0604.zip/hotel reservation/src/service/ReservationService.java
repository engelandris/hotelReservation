package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;

public class ReservationService {

    private static ReservationService reservationService;
    private ReservationService(){};
    public static ReservationService getInstance(){
        if(reservationService==null){
            reservationService=new ReservationService();
        }
        return reservationService;
    }
    public Collection<IRoom> rooms= new HashSet<>();
    public Collection<Reservation> reservations= new HashSet<>();

    public void addRoom(IRoom room){
        rooms.add(room);
    }
    public IRoom getARoom(String roomId){
        for(IRoom room: rooms){
            if(roomId.equals(room.getRoomNumber())){
                return room;
            }
        }
        return null;
    }
    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate){
        //re-write this method
        Reservation reservedRoom= new Reservation(customer, room, checkInDate, checkOutDate);
        reservations.add(reservedRoom);
        System.out.println("***Thank you for reserve***Reservation view: ");
        System.out.println(customer);
        System.out.println(room);
        System.out.println("Check-in date: "+checkInDate+ ", check out date: "+ checkOutDate);
        System.out.println(reservedRoom);
        System.out.println("**********************************");
        //Mainmenu.mainmenu();
        return reservedRoom;
    }
    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate){
        //here to add the automatic +7 days add if date is occupied
        //add body
        //re-write this, if needed
        Collection<IRoom> availableRooms = new HashSet<>();
        if(reservations.size()==0){
            availableRooms=rooms;
            return availableRooms;
        }else {
            for (Reservation res : reservations) {
                for (IRoom room : rooms) {
                    if ((room.getRoomNumber().equals(res.getRoom().getRoomNumber())) && ((checkInDate.before(res.getCheckInDate()) && checkOutDate.before(res.getCheckOutDate())) || (checkInDate.after(res.getCheckOutDate()) && checkOutDate.after(res.getCheckOutDate()))) || (!res.getRoom().getRoomNumber().contains(room.getRoomNumber()))) {
                        availableRooms.add(room);
                    } else if (room.getRoomNumber().equals(res.getRoom().getRoomNumber())) {
                        availableRooms.remove(room);
                    }
                }
            }
        }
        updAvRooms(availableRooms,checkInDate, checkOutDate);
        System.out.println("Available rooms between "+ checkInDate+ " and "+ checkOutDate+ ": ");
        System.out.println(availableRooms);
        return availableRooms;
     }
   /*     for(IRoom room: rooms) {
            if (checkInDate.after(checkInDate) && checkOutDate.before(checkOutDate)) {
                for (IRoom iRoom : rooms) {
                    System.out.println(iRoom);
                }
                return rooms;
            }*/


    private void updAvRooms(Collection<IRoom> availableRooms, Date checkInDate, Date checkOutDate) {
        for(Reservation res : reservations){
            for(IRoom room : rooms){
                if(room.getRoomNumber().equals(res.getRoom().getRoomNumber())
                    && !((checkInDate.before(res.getCheckInDate()) && checkOutDate.before(res.getCheckInDate()))
                    || (checkInDate.after(res.getCheckOutDate()) && checkOutDate.after(res.getCheckOutDate()))))
                availableRooms.remove(room);
            }
        }
    }

    public IRoom showAllRooms() {
        for (IRoom rom : rooms) {
            return rom;
        }
        return null;
    }

    public Collection<Reservation> getCustomerReservations(Customer customer) {
        //add condition
        CustomerService.getInstance().getCustomer(customer.getEmail());
        System.out.println(reservations);
        return reservations;
    }
    public void printAllReservation(){
        for(Reservation res: reservations){
                System.out.println(reservations);
                    }
    }
}

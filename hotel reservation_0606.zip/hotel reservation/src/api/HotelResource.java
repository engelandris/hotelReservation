package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.Date;

public class HotelResource {

    private static HotelResource hotelResource;
    public static CustomerService customerService=CustomerService.getInstance();
    public static ReservationService reservationService=ReservationService.getInstance();
    private HotelResource(){};
    public static HotelResource getInstance(){
        if(hotelResource==null){
            hotelResource=new HotelResource();
        }
        return hotelResource;
    }

    public Customer getCustomer(String email) {
        return customerService.getCustomer(email);
    }
    public void createACustomer(String email, String firstName, String lastName){
        //add body
        customerService.addCustomer(email, firstName, lastName);
        System.out.println("Customer was created:"+"'\n"+"email: "+ email+ ", first name: "+ firstName+ ", last name: "+ lastName);
    }
    public IRoom getRoom(String roomNumber){
        //add body
        return reservationService.getARoom(roomNumber);
    }
    public Reservation bookARoom(String customerEmail, IRoom room, Date checkInDate, Date checkOutDate){
        //add body
        Customer customer=CustomerService.getInstance().getCustomer(customerEmail); //where can I correct the problem?
        if(customer==null){
            return null;
        }
        return reservationService.reserveARoom(customer,room, checkInDate, checkOutDate);
    }
    public Collection<Reservation> getCustomerReservations (String customerEmail){
        //add body
        Customer customer=CustomerService.getInstance().getCustomer(customerEmail);
        if(customer==null){
            return null;
        }
        return reservationService.getCustomerReservations(customer);
    }
    public Collection<IRoom> findARoom(Date checkIn, Date checkOut){
        //add body
        return  reservationService.findRooms(checkIn, checkOut);
    }
}

package cli;

import api.AdminResource;
import model.IRoom;

import java.util.Scanner;

public class AdminMenu {

    public static AdminResource adminResource;

    public void start(){
        System.out.println("Please enter a number for the following actions:" + "\n"+ "1. See all Customers"+ "\n"+ "2. See all Rooms"+ "\n"+ "3. See all Reservations"+ "\n"+ "4. Add a Room"+ "\n"+ "5. Back to Main Menu");
        Scanner scanner= new Scanner(System.in);
        int action=scanner.nextInt();
        try{
            switch (action){
                case 1:
                    action = 1;
                   seeAllCustomers();
                    break;
                case 2:
                    action = 2;
                   seeAllRooms();
                    break;
                case 3:
                    action = 3;
                   seeAllReservations();
                    break;
                case 4:
                    action= 4;
                    System.out.println("not ready yet");
                  //  addARoom();
                    break;
                case 5:
                    action=5;
                    MainMenu mainMenu = new MainMenu();
                    mainMenu.startAction();
                 //   exit();
                    break;
            }

        }
        catch (Exception e) {
            System.out.println("Invalid input.");
            AdminMenu adminMenu = new AdminMenu();
            adminMenu.start();
        }
    }

  /*  private void addARoom() {
        adminResource.addRoom(IRoom rooms);
    }*/

    private void seeAllReservations() {
        adminResource.displayAllReservations();
    }

    private void seeAllRooms() {
        adminResource.getAllRooms();
    }

    private void seeAllCustomers() {
        adminResource.getAllCustomers();
    }

    public static void main(String[] args) {
        AdminMenu adMenu= new AdminMenu();
        adMenu.start();
    }

}

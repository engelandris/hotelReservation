package cli;

import api.HotelResource;
import model.IRoom;
import model.Room;
import model.RoomType;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {

    public static HotelResource hotelResource;
    public void startAction() throws Exception{
        //or throws Exception to be deleted after method()?
        System.out.println("Please enter a number for the following actions:" + "\n"+ "1. Find and reserve a room"+ "\n"+ "2. See my reservations"+ "\n"+ "3. Create an account"+ "\n"+ "4. Admin"+ "\n"+ "5. Exit");
        Scanner scanner= new Scanner(System.in);
        int action=scanner.nextInt();
        try {
            switch(action){

                case 1:
                    action = 1;
                    findAndReserveRoom();
                    break;
                case 2:
                    action = 2;
                    seeMyReservations();
                    break;
                case 3:
                    action = 3;
                    createAnAccount();
                    break;
                case 4:
                    action= 4;
                    AdminMenu adminMenu= new AdminMenu();
                    adminMenu.start();
                    break;
                case 5:
                    action=5;
                    exit();
                    break;

            }
            }
        catch (Exception e){
            System.out.println("Invalid input.");
            MainMenu mainMenu = new MainMenu();
            mainMenu.startAction();
            // startAction();
        }

       // System.out.println("Please enter a number for the following actions:" + "\n"+ "1. Find and reserve a room"+ "\n"+ "2. See my reservations"+ "\n"+ "3. Create an account"+ "\n"+ "4. Admin"+ "\n"+ "5. Exit");
    }

    private void exit() throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Do you wish to exit? y/n");
        String sScanner = scanner.nextLine();
        if (sScanner.equals("y")) {
            System.out.println("Program ended.");
            System.exit(0);
            } else if (sScanner.equals("n")){
            MainMenu mainMenu = new MainMenu();
            mainMenu.startAction();
        }


    }

    private void createAnAccount() throws Exception{
        Scanner scanner= new Scanner(System.in);
        System.out.println("Please enter your email address in 'abc@abc.com' format: ");
        String email= scanner.nextLine();
        System.out.println("Please enter your first name: ");
        String firstName= scanner.nextLine();
        System.out.println("Please enter your last name: ");
        String lastName= scanner.nextLine();
        hotelResource.createACustomer(email,firstName, lastName);

    }

    private void seeMyReservations() throws Exception {
        Scanner scanner= new Scanner(System.in);
        System.out.println("Please enter your email address in 'abc@abc.com' format: ");
        String customerEmail= scanner.nextLine();
        hotelResource.getCustomerReservations(customerEmail);

    }

    private void findAndReserveRoom() throws Exception {
        Scanner scanner= new Scanner(System.in);
        System.out.println("Please enter check-in date in the following format: dd-mm-yyyy");
        String regDate=scanner.nextLine();
        Date checkIn=new SimpleDateFormat("dd-mm-yyyy").parse(regDate);
        System.out.println("Please enter check-out date (dd-mm-yyyy): ");
        String regDate2=scanner.nextLine();
        Date checkOut=new SimpleDateFormat("dd-mm-yyyy").parse(regDate2);
        hotelResource.findARoom(checkIn, checkOut);
        System.out.println("Do you want to reserve a room? y/n");
        String choice1= scanner.nextLine();
        System.out.println("Please enter your email address in 'abc@abc.com' format: ");
        String customerEmail= scanner.nextLine();

        System.out.println("Please enter a room number: ");
        Integer roomNumber=scanner.nextInt();
        IRoom room= new IRoom() {
            @Override
            public String getRoomNumber() {
                return roomNumber.toString();
            }
            @Override
            public Double getRoomPrice() {
                return getRoomPrice();
            }
            @Override
            public RoomType getRoomType() {
                return getRoomType();
            }
            @Override
            public boolean isFree() {
                return true;
            }
        };
        hotelResource.bookARoom(customerEmail, room, checkIn, checkOut);
    }


    /*private int getAction(Scanner scanner) {
        int action=
        switch (action){
            case 1: action=1;

        }
    }*/

    public static void main(String[] args) throws Exception {

MainMenu menu =new MainMenu();
menu.startAction();

    }




}

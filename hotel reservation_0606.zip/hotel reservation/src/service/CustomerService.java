package service;

import model.Customer;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;

public class CustomerService {

    //public Collection<Customer> customerMap= new HashMap<Customer customer, email>();
    public Collection<Customer> customers= new HashSet<>();

    private static CustomerService customerService;
    private CustomerService(){};
    public static CustomerService getInstance(){
        if(customerService==null){
            customerService=new CustomerService();
        }
        return customerService;
    }

    public void addCustomer(String email, String firstName, String lastName){
        Customer plusCustomer= new Customer(firstName, lastName, email);
        customers.add(plusCustomer);
    }

    public Customer getCustomer(String customerEmail) {
        for(Customer customer: customers){
            if(customerEmail.equals(customer.getEmail())){
                return customer;
            }
        }
          return null;

    }

    public Collection<Customer> getAllCustomers() {
        for(Customer customer: customers){
                //this is not sure
                System.out.println(customer);;
            }
        return customers;
    }



}
